import time

DEFAULT_TIME = None
